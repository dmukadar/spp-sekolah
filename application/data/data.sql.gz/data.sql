-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 03, 2012 at 05:00 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `alazka`
--

-- --------------------------------------------------------

--
-- Table structure for table `ar_billing`
--

CREATE TABLE IF NOT EXISTS `ar_billing` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_rate` bigint(20) unsigned DEFAULT NULL,
  `id_class` bigint(20) unsigned DEFAULT '0',
  `due_after` int(10) unsigned DEFAULT '0',
  `recurrence` enum('sekali','tahun','semester','cawu','bulan') DEFAULT 'sekali',
  `installment` tinyint(3) unsigned DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` bigint(20) unsigned DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `ar_billing`
--


-- --------------------------------------------------------

--
-- Table structure for table `ar_custom_rate`
--

CREATE TABLE IF NOT EXISTS `ar_custom_rate` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_rate` bigint(20) unsigned DEFAULT NULL,
  `id_student` bigint(20) unsigned DEFAULT NULL,
  `fare` decimal(9,2) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` bigint(20) unsigned DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `ar_custom_rate`
--


-- --------------------------------------------------------

--
-- Table structure for table `ar_invoice`
--

CREATE TABLE IF NOT EXISTS `ar_invoice` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(100) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `id_employee` bigint(20) unsigned DEFAULT NULL,
  `id_student` bigint(20) unsigned DEFAULT NULL,
  `id_rate` bigint(20) unsigned DEFAULT NULL,
  `amount` decimal(9,2) DEFAULT NULL,
  `status` tinyint(3) unsigned DEFAULT '0',
  `notes` varchar(255) DEFAULT NULL,
  `last_installment` tinyint(3) unsigned DEFAULT '0',
  `received_amount` decimal(9,2) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` bigint(20) unsigned DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `ar_invoice`
--


-- --------------------------------------------------------

--
-- Table structure for table `ar_payment`
--

CREATE TABLE IF NOT EXISTS `ar_payment` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_employee` bigint(20) unsigned DEFAULT NULL,
  `received_date` date DEFAULT NULL,
  `amount` decimal(9,2) DEFAULT NULL,
  `status` tinyint(3) unsigned DEFAULT '0',
  `notes` varchar(255) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` bigint(20) unsigned DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `ar_payment`
--


-- --------------------------------------------------------

--
-- Table structure for table `ar_payment_details`
--

CREATE TABLE IF NOT EXISTS `ar_payment_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_payment` bigint(20) unsigned DEFAULT NULL,
  `id_invoice` bigint(20) unsigned DEFAULT NULL,
  `amount` decimal(9,2) DEFAULT NULL,
  `installment` tinyint(3) unsigned DEFAULT NULL,
  `status` tinyint(3) unsigned DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` bigint(20) unsigned DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `ar_payment_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `ar_rate`
--

CREATE TABLE IF NOT EXISTS `ar_rate` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(20) DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `fare` decimal(9,2) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` bigint(20) unsigned DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `ar_rate`
--

INSERT INTO `ar_rate` (`id`, `category`, `name`, `description`, `fare`, `created`, `modified`, `modified_by`) VALUES
(1, 'SPP', 'Uang SPP', 'Sumbangan Pengembangan Pendidikan', '455000.00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL),
(2, 'Uang Masuk TA', 'Uang Masuk Taman Azhar', NULL, '7000000.00', '0000-00-00 00:00:00', '2011-12-20 11:53:52', NULL),
(3, 'Uang Masuk SD1', 'Uang Masuk SD Kelas 1', NULL, '6000000.00', '0000-00-00 00:00:00', '2011-12-20 11:54:03', NULL),
(4, 'Uang Buku TA', 'Uang Buku Paket Taman Azhar', NULL, '200000.00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL),
(5, 'Uang Buku TA', 'Uang Buku Non Paket Taman Azhar', NULL, '100000.00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL),
(6, 'Uang Buku TA', 'Uang Buku LKS Taman Azhar', NULL, '50000.00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL),
(7, 'Uang Buku TA', 'Uang Buku Lain-lain Taman Azhar', NULL, '75000.00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL),
(8, 'Uang Kegiatan TA', 'Uang Kegiatan Taman Azhar', NULL, '15000.00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL),
(9, 'Uang Seragam TA', 'Uang Seragam Taman Azhar', NULL, '125000.00', '0000-00-00 00:00:00', '2011-12-20 11:55:06', NULL),
(10, 'Uang Seragam SD', 'Uang Seragam SD', NULL, '125000.00', '0000-00-00 00:00:00', '2011-12-20 11:55:06', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ar_user`
--

CREATE TABLE IF NOT EXISTS `ar_user` (
  `user_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(16) NOT NULL,
  `user_first_name` varchar(20) NOT NULL,
  `user_last_name` varchar(20) NOT NULL,
  `user_pass` varchar(32) NOT NULL,
  `user_salt` char(8) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_status` tinyint(1) unsigned DEFAULT '1' COMMENT '0 = Deleted|1 = Pending|2 = Blocked|3 = Profile Empty|4 = Active',
  `user_join_date` int(10) DEFAULT NULL,
  `user_last_login` int(10) DEFAULT NULL,
  `pegawai_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`username`),
  UNIQUE KEY `user_email` (`user_email`),
  KEY `USERNAME_IDX` (`username`,`user_status`),
  KEY `PASS_IDX` (`user_pass`),
  KEY `SEARCHABLE_IDX` (`user_email`,`user_last_name`,`user_first_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ar_user`
--

INSERT INTO `ar_user` (`user_id`, `username`, `user_first_name`, `user_last_name`, `user_pass`, `user_salt`, `user_email`, `user_status`, `user_join_date`, `user_last_login`, `pegawai_id`) VALUES
(1, 'admin', 'Super', 'Admin', '932c189a06cdced2f9ff0e0019d4c60c', 'd.{S.P|*', 'admin@localhost.org', 4, NULL, NULL, NULL),
(2, 'guest', 'Guest', 'User', 'foobar', '12345', 'guest@localhost.com', 4, NULL, NULL, NULL);
