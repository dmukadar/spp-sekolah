-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 18, 2012 at 07:05 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `alazka`
--

-- --------------------------------------------------------

--
-- Table structure for table `ar_billing`
--

CREATE TABLE IF NOT EXISTS `ar_billing` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_rate` bigint(20) unsigned DEFAULT NULL,
  `id_class` bigint(20) unsigned DEFAULT '0',
  `due_after` int(10) unsigned DEFAULT '0',
  `recurrence` enum('sekali','tahun','semester','cawu','bulan') DEFAULT 'sekali',
  `installment` tinyint(3) unsigned DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` bigint(20) unsigned DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ar_custom_rate`
--

CREATE TABLE IF NOT EXISTS `ar_custom_rate` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_rate` bigint(20) unsigned DEFAULT NULL,
  `id_student` bigint(20) unsigned DEFAULT NULL,
  `fare` decimal(9,2) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` bigint(20) unsigned DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

-- --------------------------------------------------------

--
-- Table structure for table `ar_invoice`
--

CREATE TABLE IF NOT EXISTS `ar_invoice` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(100) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `id_employee` bigint(20) unsigned DEFAULT NULL,
  `id_student` bigint(20) unsigned DEFAULT NULL,
  `id_rate` bigint(20) unsigned DEFAULT NULL,
  `amount` decimal(9,2) DEFAULT NULL,
  `status` tinyint(3) unsigned DEFAULT '0',
  `notes` varchar(255) DEFAULT NULL,
  `last_installment` tinyint(3) unsigned DEFAULT '0',
  `received_amount` decimal(9,2) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` bigint(20) unsigned DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=40 ;

-- --------------------------------------------------------

--
-- Table structure for table `ar_payment`
--

CREATE TABLE IF NOT EXISTS `ar_payment` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_employee` bigint(20) unsigned DEFAULT NULL,
  `received_date` date DEFAULT NULL,
  `amount` decimal(9,2) DEFAULT NULL,
  `status` tinyint(3) unsigned DEFAULT '0',
  `notes` varchar(255) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` bigint(20) unsigned DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ar_payment_details`
--

CREATE TABLE IF NOT EXISTS `ar_payment_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_payment` bigint(20) unsigned DEFAULT NULL,
  `id_invoice` bigint(20) unsigned DEFAULT NULL,
  `amount` decimal(9,2) DEFAULT NULL,
  `remaining_amount` decimal(9,2) DEFAULT NULL,
  `installment` tinyint(3) unsigned DEFAULT NULL,
  `status` tinyint(3) unsigned DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` bigint(20) unsigned DEFAULT NULL,
  UNIQUE KEY `id` (`id`),
  KEY `remaining_amount` (`remaining_amount`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ar_rate`
--

CREATE TABLE IF NOT EXISTS `ar_rate` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(20) DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `fare` decimal(9,2) DEFAULT NULL,
  `id_kelas` int(10) unsigned DEFAULT NULL,
  `due_after` int(10) unsigned DEFAULT '10',
  `recurrence` enum('sekali','tahun','semester','cawu','bulan') DEFAULT 'sekali',
  `installment` tinyint(3) unsigned DEFAULT '1',
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` bigint(20) unsigned DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38 ;

-- --------------------------------------------------------

--
-- Table structure for table `ar_user`
--

CREATE TABLE IF NOT EXISTS `ar_user` (
  `user_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(16) NOT NULL,
  `user_first_name` varchar(20) NOT NULL,
  `user_last_name` varchar(20) NOT NULL,
  `user_pass` varchar(32) NOT NULL,
  `user_salt` char(8) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_status` tinyint(1) unsigned DEFAULT '1' COMMENT '0 = Deleted|1 = Pending|2 = Blocked|3 = Profile Empty|4 = Active',
  `user_join_date` int(10) DEFAULT NULL,
  `user_last_login` int(10) DEFAULT NULL,
  `pegawai_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`username`),
  UNIQUE KEY `user_email` (`user_email`),
  KEY `USERNAME_IDX` (`username`,`user_status`),
  KEY `PASS_IDX` (`user_pass`),
  KEY `SEARCHABLE_IDX` (`user_email`,`user_last_name`,`user_first_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `dm_agama`
--

CREATE TABLE IF NOT EXISTS `dm_agama` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nama_UNIQUE` (`nama`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `dm_agendaumum`
--

CREATE TABLE IF NOT EXISTS `dm_agendaumum` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tglmulai` date NOT NULL,
  `tglselesai` date NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'Libur',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

-- --------------------------------------------------------

--
-- Table structure for table `dm_jenjang`
--

CREATE TABLE IF NOT EXISTS `dm_jenjang` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `dm_kelas`
--

CREATE TABLE IF NOT EXISTS `dm_kelas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kelas` varchar(50) NOT NULL,
  `dm_jenjang_id` int(11) NOT NULL,
  `jenjang` varchar(50) NOT NULL,
  `angka` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

-- --------------------------------------------------------

--
-- Table structure for table `dm_mapel`
--

CREATE TABLE IF NOT EXISTS `dm_mapel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `kode` varchar(45) DEFAULT NULL,
  `dm_jenjang_id` int(11) NOT NULL,
  `jumlahjam` int(11) DEFAULT '0',
  `kkm` int(11) DEFAULT NULL,
  `urutanraport` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

-- --------------------------------------------------------

--
-- Table structure for table `dm_rumus`
--

CREATE TABLE IF NOT EXISTS `dm_rumus` (
  `id` int(11) NOT NULL,
  `np` int(11) NOT NULL,
  `uts` int(11) NOT NULL,
  `uas` int(11) NOT NULL,
  `pembagi` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dm_statusabsen`
--

CREATE TABLE IF NOT EXISTS `dm_statusabsen` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `dm_statussiswa`
--

CREATE TABLE IF NOT EXISTS `dm_statussiswa` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(45) NOT NULL COMMENT 'Siswa, Lulus (Alumni), Keluar',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Table structure for table `dm_statustanggal`
--

CREATE TABLE IF NOT EXISTS `dm_statustanggal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dm_tahunpelajaran_id` int(11) NOT NULL,
  `tglawal` date NOT NULL,
  `tglakhir` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dm_tahunpelajaran_id_UNIQUE` (`dm_tahunpelajaran_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `dm_tahunpelajaran`
--

CREATE TABLE IF NOT EXISTS `dm_tahunpelajaran` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tahun` varchar(20) NOT NULL,
  `aktif` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Table structure for table `dm_tanggal`
--

CREATE TABLE IF NOT EXISTS `dm_tanggal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tanggal` date NOT NULL,
  `hari` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL COMMENT 'Libur atau Masuk',
  `dm_tahunpelajaran_id` int(11) DEFAULT NULL,
  `dm_agendaumum_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2192 ;

-- --------------------------------------------------------

--
-- Table structure for table `dm_uangmasuk`
--

CREATE TABLE IF NOT EXISTS `dm_uangmasuk` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dm_tahunpelajaran_id` int(11) NOT NULL,
  `kodekelas` varchar(5) NOT NULL,
  `kelas` varchar(50) NOT NULL,
  `jumlah` varchar(10) NOT NULL,
  `useragam` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `dm_uangtahunan`
--

CREATE TABLE IF NOT EXISTS `dm_uangtahunan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dm_tahunpelajaran_id` int(11) NOT NULL,
  `kodekelas` varchar(5) NOT NULL,
  `kelas` varchar(50) NOT NULL,
  `uangkegiatan` varchar(10) NOT NULL,
  `uangbuku` varchar(10) NOT NULL,
  `uangnonbuku` varchar(10) NOT NULL,
  `spp` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `inbox`
--

CREATE TABLE IF NOT EXISTS `inbox` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `msgid` varchar(255) DEFAULT NULL,
  `tipe` varchar(255) DEFAULT NULL,
  `tglkirim` varchar(255) DEFAULT NULL,
  `tglterima` varchar(255) DEFAULT NULL,
  `nopengirim` varchar(255) DEFAULT NULL,
  `nopenerima` varchar(255) DEFAULT NULL,
  `isipesan` text,
  `status` varchar(20) DEFAULT NULL,
  `baru` tinyint(1) DEFAULT NULL,
  `nama` varchar(255) DEFAULT NULL COMMENT 'Nama Pengirim',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='SMS yang Masuk' AUTO_INCREMENT=3019 ;

-- --------------------------------------------------------

--
-- Table structure for table `keu_spp`
--

CREATE TABLE IF NOT EXISTS `keu_spp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sis_statussiswa_id` int(11) NOT NULL,
  `bulan` varchar(2) NOT NULL,
  `tahun` varchar(4) NOT NULL,
  `tgl_bayar` date NOT NULL,
  `jumlah` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=52 ;

-- --------------------------------------------------------

--
-- Table structure for table `keu_uangmasuk`
--

CREATE TABLE IF NOT EXISTS `keu_uangmasuk` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sis_siswa_id` int(11) NOT NULL,
  `tahun_pelajaran` varchar(20) DEFAULT NULL,
  `jumlah` varchar(25) DEFAULT NULL,
  `sisa` varchar(25) DEFAULT NULL,
  `useragam` varchar(25) DEFAULT NULL,
  `tglbyrseragam` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=86 ;

-- --------------------------------------------------------

--
-- Table structure for table `keu_umcicilan`
--

CREATE TABLE IF NOT EXISTS `keu_umcicilan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `keu_uangmasuk_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `jumlah` varchar(25) NOT NULL,
  `angsuranke` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `outbox`
--

CREATE TABLE IF NOT EXISTS `outbox` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `msgid` varchar(255) NOT NULL,
  `tipe` varchar(255) DEFAULT NULL,
  `tanggal` datetime NOT NULL,
  `tujuan` varchar(255) NOT NULL,
  `isipesan` text,
  `status` varchar(20) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL COMMENT 'Catatan Nama Group Tujuan apabila ada',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='SMS yang Dikirim' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `peg_anak`
--

CREATE TABLE IF NOT EXISTS `peg_anak` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `peg_pegawai_id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `jeniskelamin` varchar(1) DEFAULT NULL,
  `statusanak` varchar(2) DEFAULT NULL COMMENT 'AK = Anak Kandung\nAT = Anak Tiri\nAA = Anak Angkat',
  `tempatlahir` varchar(45) DEFAULT NULL,
  `tgllahir` date DEFAULT NULL,
  `namaibuayah` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

-- --------------------------------------------------------

--
-- Table structure for table `peg_keorganisasian`
--

CREATE TABLE IF NOT EXISTS `peg_keorganisasian` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `peg_pegawai_id` int(11) NOT NULL,
  `namaorganisasi` varchar(255) NOT NULL,
  `jabatan` varchar(255) DEFAULT NULL,
  `tahun` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `peg_kursus`
--

CREATE TABLE IF NOT EXISTS `peg_kursus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `peg_pegawai_id` int(11) NOT NULL,
  `jenis` varchar(255) NOT NULL,
  `tempat` varchar(255) DEFAULT NULL,
  `lamatahun` int(11) DEFAULT NULL,
  `lamabulan` int(11) DEFAULT NULL,
  `lamahari` int(11) DEFAULT NULL,
  `tingkat` varchar(100) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `peg_pasangan`
--

CREATE TABLE IF NOT EXISTS `peg_pasangan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `peg_pegawai_id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `tgllahir` date DEFAULT NULL,
  `tglnikah` date DEFAULT NULL,
  `keterangan` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

-- --------------------------------------------------------

--
-- Table structure for table `peg_pegawai`
--

CREATE TABLE IF NOT EXISTS `peg_pegawai` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nip` varchar(45) DEFAULT NULL,
  `nama` varchar(100) NOT NULL,
  `statusguru` varchar(255) NOT NULL DEFAULT '-',
  `jeniskelamin` varchar(1) NOT NULL,
  `tempatlahir` varchar(45) DEFAULT NULL,
  `tgllahir` date DEFAULT NULL,
  `dm_agama_id` int(11) DEFAULT NULL,
  `warganegara` varchar(45) DEFAULT NULL,
  `statuskawin` varchar(20) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `statusrumah` varchar(45) DEFAULT NULL,
  `notelp` varchar(45) DEFAULT NULL,
  `nosms` varchar(16) DEFAULT NULL,
  `jarak` varchar(10) DEFAULT NULL,
  `berat` varchar(10) DEFAULT NULL,
  `tinggi` varchar(10) DEFAULT NULL,
  `goldarah` varchar(4) DEFAULT NULL,
  `penyakitdulu` varchar(255) DEFAULT NULL,
  `kelainan` varchar(255) DEFAULT NULL,
  `hobi` varchar(255) DEFAULT NULL,
  `statuspegawai` varchar(100) DEFAULT NULL,
  `tglmasuk` date DEFAULT NULL,
  `asal` varchar(45) DEFAULT NULL,
  `tglkeluar` date DEFAULT NULL,
  `alasankeluar` text,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=77 ;

-- --------------------------------------------------------

--
-- Table structure for table `peg_pendidikan`
--

CREATE TABLE IF NOT EXISTS `peg_pendidikan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `peg_pegawai_id` int(11) NOT NULL,
  `jenis` varchar(255) NOT NULL,
  `berijazah` varchar(45) DEFAULT NULL,
  `tahun` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `peg_riwayat_kerja`
--

CREATE TABLE IF NOT EXISTS `peg_riwayat_kerja` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `peg_pegawai_id` int(11) NOT NULL,
  `jenis` varchar(255) NOT NULL,
  `tahun` varchar(45) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `peg_riwayat_mengajar`
--

CREATE TABLE IF NOT EXISTS `peg_riwayat_mengajar` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `peg_pegawai_id` int(11) NOT NULL,
  `namamapel` varchar(255) NOT NULL,
  `sekolah` varchar(255) DEFAULT NULL,
  `kelas` varchar(45) DEFAULT NULL,
  `tahun` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `sis_absen_harian`
--

CREATE TABLE IF NOT EXISTS `sis_absen_harian` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sis_statussiswa_id` int(11) NOT NULL,
  `dm_tanggal_id` int(11) NOT NULL,
  `dm_statusabsen_id` int(11) NOT NULL,
  `terlambat` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=Ya, 0=Tidak',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `sis_kdmapel`
--

CREATE TABLE IF NOT EXISTS `sis_kdmapel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sis_mapelkelas_id` int(11) NOT NULL,
  `semester` varchar(10) NOT NULL,
  `kd1` text NOT NULL,
  `kd2` text,
  `kd3` text,
  `kd4` text,
  `kd5` text,
  `kd6` text,
  `kd7` text,
  `kd8` text,
  `kduts` int(11) NOT NULL DEFAULT '4',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=190 ;

-- --------------------------------------------------------

--
-- Table structure for table `sis_kelasaktif`
--

CREATE TABLE IF NOT EXISTS `sis_kelasaktif` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dm_tahunpelajaran_id` int(11) NOT NULL,
  `dm_kelas_id` int(11) NOT NULL,
  `peg_pegawai_id` int(11) NOT NULL,
  `namakelas` varchar(50) DEFAULT NULL,
  `namawalikelas` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

-- --------------------------------------------------------

--
-- Table structure for table `sis_kesehatan`
--

CREATE TABLE IF NOT EXISTS `sis_kesehatan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sis_siswa_id` int(11) NOT NULL,
  `goldarah` varchar(4) DEFAULT NULL,
  `berat` varchar(10) DEFAULT NULL,
  `tinggi` varchar(10) DEFAULT NULL,
  `tekanandarah` varchar(20) DEFAULT NULL,
  `kuku` varchar(100) DEFAULT NULL,
  `rambut` varchar(100) DEFAULT NULL,
  `mata` varchar(100) DEFAULT NULL,
  `telinga` varchar(100) DEFAULT NULL,
  `hidung` varchar(100) DEFAULT NULL,
  `mulut` varchar(100) DEFAULT NULL,
  `gigi` varchar(100) DEFAULT NULL,
  `imunisasi_polio` varchar(100) DEFAULT NULL,
  `imunisasi_bcg` varchar(100) DEFAULT NULL,
  `imunisasi_dpt` varchar(100) DEFAULT NULL,
  `imunisasi_cacar` varchar(100) DEFAULT NULL,
  `imunisasi_chotypa` varchar(100) DEFAULT NULL,
  `imunisasi_campak` varchar(100) DEFAULT NULL,
  `riwayatpenyakit` text,
  `kelainan_jasmani` text,
  `alergi_obat` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sis_siswa_id_UNIQUE` (`sis_siswa_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='1 siswa 1 catatan kesehatan' AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Table structure for table `sis_mapelkelas`
--

CREATE TABLE IF NOT EXISTS `sis_mapelkelas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sis_kelasaktif_id` int(11) NOT NULL,
  `dm_mapel_id` int(11) NOT NULL,
  `peg_pegawai_id` int(11) NOT NULL,
  `namamapel` varchar(100) DEFAULT NULL,
  `kkm` int(11) DEFAULT NULL,
  `namaguru` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=212 ;

-- --------------------------------------------------------

--
-- Table structure for table `sis_nilai`
--

CREATE TABLE IF NOT EXISTS `sis_nilai` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sis_statussiswa_id` int(11) NOT NULL,
  `sis_mapelkelas_id` int(11) NOT NULL,
  `semester` varchar(10) NOT NULL,
  `nkd1` double DEFAULT NULL,
  `nkd2` double DEFAULT NULL,
  `nkd3` double DEFAULT NULL,
  `nkd4` double DEFAULT NULL,
  `nkd5` double DEFAULT NULL,
  `nkd6` double DEFAULT NULL,
  `nkd7` double DEFAULT NULL,
  `nkd8` double DEFAULT NULL,
  `np` double DEFAULT NULL,
  `uts` double DEFAULT NULL,
  `uas` double DEFAULT NULL,
  `nraport` double DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1309 ;

-- --------------------------------------------------------

--
-- Table structure for table `sis_orangtua`
--

CREATE TABLE IF NOT EXISTS `sis_orangtua` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `namaayah` varchar(100) DEFAULT NULL,
  `tempatlahirayah` varchar(45) DEFAULT NULL,
  `tgllahirayah` date DEFAULT NULL,
  `agamaayah` varchar(45) DEFAULT NULL,
  `warganegaraayah` varchar(100) DEFAULT NULL,
  `pendidikanayah` varchar(100) DEFAULT NULL,
  `pekerjaanayah` varchar(255) DEFAULT NULL,
  `instansiayah` varchar(255) DEFAULT NULL,
  `penghasilanayah` varchar(45) DEFAULT NULL,
  `alamatayah` varchar(255) DEFAULT NULL,
  `notelpayah` varchar(45) DEFAULT NULL,
  `nohpayah` varchar(45) DEFAULT NULL,
  `emailayah` varchar(100) DEFAULT NULL,
  `nosms` varchar(20) DEFAULT NULL,
  `namaibu` varchar(100) DEFAULT NULL,
  `tempatlahiribu` varchar(45) DEFAULT NULL,
  `tgllahiribu` date DEFAULT NULL,
  `agamaibu` varchar(45) DEFAULT NULL,
  `warganegaraibu` varchar(100) DEFAULT NULL,
  `pendidikanibu` varchar(100) DEFAULT NULL,
  `pekerjaanibu` varchar(255) DEFAULT NULL,
  `instansiibu` varchar(255) DEFAULT NULL,
  `penghasilanibu` varchar(45) DEFAULT NULL,
  `alamatibu` varchar(255) DEFAULT NULL,
  `notelpibu` varchar(45) DEFAULT NULL,
  `nohpibu` varchar(45) DEFAULT NULL,
  `emailibu` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=290 ;

-- --------------------------------------------------------

--
-- Table structure for table `sis_siswa`
--

CREATE TABLE IF NOT EXISTS `sis_siswa` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `noinduk` varchar(20) DEFAULT NULL,
  `nisn` varchar(20) DEFAULT NULL,
  `nodaftar` varchar(20) DEFAULT NULL,
  `tgldaftar` date DEFAULT NULL,
  `dm_jenjang_id` int(11) NOT NULL,
  `dm_kelas_id` int(11) DEFAULT NULL,
  `namalengkap` varchar(100) NOT NULL,
  `namapanggilan` varchar(30) DEFAULT NULL,
  `jeniskelamin` varchar(1) DEFAULT NULL COMMENT 'L/P',
  `jmlsaudara` int(11) DEFAULT NULL,
  `anakke` int(11) DEFAULT NULL,
  `tempatlahir` varchar(45) DEFAULT NULL,
  `tgllahir` date DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `telp` varchar(45) DEFAULT NULL,
  `dm_agama_id` int(11) DEFAULT NULL,
  `bahasaibu` varchar(45) DEFAULT NULL,
  `bahasalisan` varchar(45) DEFAULT NULL,
  `tinggaldengan` varchar(45) DEFAULT NULL,
  `sekolahasal` varchar(255) DEFAULT NULL,
  `alamatsekolah` varchar(255) DEFAULT NULL,
  `tahunsekolah` varchar(10) DEFAULT NULL COMMENT 'tahun ajaran',
  `iq` varchar(10) DEFAULT NULL,
  `gayabelajar` text,
  `kecerdasanmajemuk` text,
  `kesulitanbelajar` text,
  `sis_orangtua_id` int(11) DEFAULT NULL,
  `sis_wali_id` int(11) DEFAULT NULL,
  `dm_statussiswa_id` int(11) NOT NULL DEFAULT '1',
  `idstatussiswa` int(11) NOT NULL DEFAULT '0' COMMENT 'sis_statussiswa_id yg aktif sekarang',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=404 ;

-- --------------------------------------------------------

--
-- Table structure for table `sis_statussiswa`
--

CREATE TABLE IF NOT EXISTS `sis_statussiswa` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sis_siswa_id` int(11) NOT NULL,
  `dm_tahunpelajaran_id` int(11) NOT NULL,
  `dm_jenjang_id` int(11) NOT NULL,
  `sis_kelasaktif_id` int(11) NOT NULL,
  `hasil_kenaikan_kelas` varchar(45) DEFAULT NULL COMMENT 'Naik Kelas, Tidak Naik Kelas',
  `catatan_evaluasi` text,
  `uang_kegiatan` varchar(25) DEFAULT NULL,
  `uang_buku` varchar(25) DEFAULT NULL,
  `uang_nonbuku` varchar(25) DEFAULT NULL,
  `tglbyr_ukegiatan` date DEFAULT NULL,
  `tglbyr_ubuku` date DEFAULT NULL,
  `tglbyr_unonbuku` date DEFAULT NULL,
  `spp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=399 ;

-- --------------------------------------------------------

--
-- Table structure for table `sis_wali`
--

CREATE TABLE IF NOT EXISTS `sis_wali` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `tempatlahir` varchar(45) DEFAULT NULL,
  `tgllahir` date DEFAULT NULL,
  `dm_agama_id` int(11) DEFAULT NULL,
  `warganegara` varchar(100) DEFAULT NULL,
  `pendidikan` varchar(100) DEFAULT NULL,
  `pekerjaan` varchar(255) DEFAULT NULL,
  `instansi` varchar(255) DEFAULT NULL,
  `penghasilan` varchar(45) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `notelp` varchar(45) DEFAULT NULL,
  `nohp` varchar(45) DEFAULT NULL,
  `nosms` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `hubungan` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `sms_anggotagrup`
--

CREATE TABLE IF NOT EXISTS `sms_anggotagrup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sms_gruptelp_id` int(11) NOT NULL,
  `sms_bukutelp_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=105 ;

-- --------------------------------------------------------

--
-- Table structure for table `sms_autoforward`
--

CREATE TABLE IF NOT EXISTS `sms_autoforward` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nohp_asal` varchar(25) NOT NULL,
  `katakunci` varchar(50) NOT NULL,
  `idgrup` varchar(20) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `katakunci_UNIQUE` (`katakunci`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `sms_autoreply`
--

CREATE TABLE IF NOT EXISTS `sms_autoreply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `katakunci` varchar(50) NOT NULL,
  `proses` varchar(50) NOT NULL,
  `pesan` text,
  `aktif` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=Ya, 0=Tidak',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `katakunci_UNIQUE` (`katakunci`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `sms_bukutelp`
--

CREATE TABLE IF NOT EXISTS `sms_bukutelp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `keterangan` text,
  `nohp1` varchar(20) NOT NULL,
  `status1` tinyint(1) NOT NULL,
  `nohp2` varchar(20) DEFAULT NULL,
  `status2` tinyint(1) DEFAULT NULL,
  `nohp3` varchar(20) DEFAULT NULL,
  `status3` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nama_UNIQUE` (`nama`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=101 ;

-- --------------------------------------------------------

--
-- Table structure for table `sms_gruptelp`
--

CREATE TABLE IF NOT EXISTS `sms_gruptelp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `keterangan` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

-- --------------------------------------------------------

--
-- Table structure for table `sms_katakunci`
--

CREATE TABLE IF NOT EXISTS `sms_katakunci` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `status` varchar(25) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nama_UNIQUE` (`nama`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Table structure for table `sms_template`
--

CREATE TABLE IF NOT EXISTS `sms_template` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) NOT NULL,
  `pesan` text NOT NULL,
  `jmlkarakter` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `sms_terjadwal`
--

CREATE TABLE IF NOT EXISTS `sms_terjadwal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) NOT NULL,
  `pesan` text NOT NULL,
  `jmlkarakter` int(11) DEFAULT NULL,
  `tanggal` datetime NOT NULL,
  `status` varchar(25) DEFAULT NULL COMMENT 'Baru atau Terkirim',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `idgruptujuan` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '	',
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `peg_pegawai_id` int(11) DEFAULT NULL,
  `usergroup_id` int(11) NOT NULL,
  `keterangan` text,
  `grupsms` tinyint(1) NOT NULL,
  `aktif` int(11) NOT NULL DEFAULT '1',
  `hit` int(11) NOT NULL DEFAULT '0',
  `lastlogin` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Table structure for table `usergroup`
--

CREATE TABLE IF NOT EXISTS `usergroup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `kode` varchar(50) NOT NULL,
  `keterangan` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Grup untuk Sis Akademiknya' AUTO_INCREMENT=8 ;
